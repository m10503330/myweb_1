#include<stdio.h>
#include<stdlib.h>

struct _node
{
	int data;
	struct _node *next;
};

typedef struct _node node;
node *insertdata(node *, node *, int);
int printlist(node *);
int printlistnum(node *);
void freenode(node *);
node *foundnode(node *, int);
node *deletenode(node *, int);


int main()
{
	char op;
	int newdata, index, value, fdata, ddata;
	node *head = NULL, *ptr = NULL;



	while (1)
	{
		
		puts("i ���J���Ƴ̫�");
		puts("j ���J���Ƴ̫e");
		puts("m ���J��ƨ��N�Ӧ�m");
		puts("n ���J��ƨ�Y��ƫ��");
		puts("d �R�����");
		puts("f �M����");
		puts("g ��ܸ�ƭӼ�");
		puts("l �C�X���");
		puts("q ���}");
		
		scanf(" %c", &op);

		switch (op)
		{
		case 'i':
			scanf(" %d", &newdata);
			ptr = head;
			while (head != NULL && ptr->next != NULL)
			{
				ptr = ptr->next;
			}

			head = insertdata(head, ptr, newdata);
			break;
		case 'j':
			scanf(" %d", &newdata);
			head = insertdata(head, NULL, newdata);
			break;
		case 'm':
			ptr = head;
			scanf(" %d", &index);
			scanf(" %d", &newdata);
			for (int i = 1; i < index; i++)
			{
				ptr = ptr->next;
				if (ptr->next == NULL)
					break;
			}
			if (index == 0)
				ptr = NULL;

			head = insertdata(head, ptr, newdata);
			break;
		case 'n':

			scanf(" %d", &value);
			ptr = foundnode(head, value);
			if (ptr == NULL)
				printf("%d not found, can not insert\n", value);
			else
			{
				scanf(" %d", &newdata);
				head = insertdata(head, ptr, newdata);
			}
			break;
		case 'd':
			scanf(" %d", &ddata);
			head = deletenode(head, ddata);
			printf("Delete ok\n");
			break;
		case 'f':
			scanf(" %d", &fdata);

			if (foundnode(head, fdata) == NULL)
			{
				printf("can't found %d\n", fdata);
			}
			else
			{
				printf("found %d\n", fdata);
			}

			break;
		case 'g':
			printf("�ثe�� %d �����\n", printlistnum(head));
			break;
		case 'l':
			printlist(head);
			break;
		case 'q':
			freenode(head);
			return 0;
			break;


		}
		
		system("pause");
		system("cls");
		
	}



	return 0;
}

node *insertdata(node *head, node *ptr, int newdata)
{
	node *newnode;
	newnode = (node *)malloc(sizeof(node));
	newnode->data = newdata;
	newnode->next = NULL;
	if (head == NULL)
	{
		return newnode;
	}
	else
	{
		if (ptr == NULL)
		{
			newnode->next = head;
			return newnode;
		}
		else
		{
			newnode->next = ptr->next;
			ptr->next = newnode;

		}
	}
	return head;

}

int printlist(node *head)
{
	int count = 0;
	while (head != NULL)
	{
		printf("%d ", head->data);
		head = head->next;
		count++;
	}
	printf("\n");
	return count;
}

int printlistnum(node *head)
{
	int count = 0;
	while (head != NULL)
	{
		count++;
		head = head->next;
	}
	
	return count;
}

void freenode(node *head)
{
	node *ptr2;
	while (head != NULL)
	{
		ptr2 = head->next;
		free(head);
		head = ptr2;

	}

}

node *foundnode(node *head, int fdata)
{
	node *ptr = head;
	while (ptr != NULL && ptr->data != fdata)
	{
		
		if (ptr == NULL)
		{
			return NULL;
		}
		ptr = ptr->next;
	}
	return ptr;

}

node *deletenode(node *head, int ddata)
{
	node *ptr = head, *parent;
	while (ptr != NULL)
	{
		if (ptr->data == ddata)
		{
			if (ptr == head)
			{
				ptr = ptr->next;
				free(head);
				return ptr;
			}
			else
			{
				parent->next = ptr->next;
				free(ptr);
				return head;
			}

		}

		parent = ptr;
		ptr = ptr->next;
	}

}